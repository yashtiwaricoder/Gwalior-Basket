

export default function Spacer()
{
    return(
        <div style={{width:"100%",height:20}}>

        </div>
    )
}